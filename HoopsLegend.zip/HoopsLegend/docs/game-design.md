# Game Design — HoopsLegend (working title)

## Document control

| Field | Value |
|---|---|
| Document ID | CR-DOC-004 |
| Title | Game Design |
| Project | HoopsLegend (working title) |
| Version | 1.1 |
| Status | Design draft |
| Classification | Internal / Confidential |
| Date created | 8 September 2026 |

Status tags: **DECIDED** · **PROPOSED** · **OPEN QUESTION** · **FUTURE** · **REJECTED**

Internal use only. Working game design for a **blockchain basketball** product. Numbers and modes tagged PROPOSED are still open until we playtest.

---

## Game identity

**PROPOSED:** Blockchain basketball you can feel in seconds and deepen over seasons — **owned players** on-chain, careers and clubs underneath competitive matches.

Tone: competitive and athletic, club + collector culture — not casino chrome. Ownership is visible in the product, not hidden.

---

## Genre

| Layer | Classification |
|---|---|
| Primary | Blockchain sports / owned-athlete basketball |
| Secondary | Competitive sports action |
| Tertiary | Progression / light sports management |

---

## Platforms *(PROPOSED)*

| Platform | Notes |
|---|---|
| PC | Primary prototype target *(PROPOSED)* |
| Mobile | Touch controls later or companion—OPEN QUESTION |
| Console | FUTURE / OPEN QUESTION |

**OPEN QUESTION:** Exact launch platform set.

---

## Game modes

| Mode | Description | MVP? |
|---|---|---|
| **3v3** | Recommended core competitive mode | **PROPOSED MVP yes** |
| 1v1 | Duel / training | Optional early |
| 5v5 | Full team sim feel | Post-MVP (complexity) |
| Ranked | Ladder / MMR | MVP path |
| Casual | Unranked | MVP path |
| Tournament | Brackets | Progressive |
| League | Season schedules | Expansion |
| Training | Drills / practice | MVP light |
| Management | Lineups, tactics UI | Light MVP → deep later |

**PROPOSED MVP mode:** 3v3 ranked + casual + basic training.

---

## Match structure *(PROPOSED values — not final)*

| Element | Proposal | Status |
|---|---|---|
| Match length | 2 halves × 4–5 minutes effective play | PROPOSED |
| Scoring | Standard 2 / 3; free throws simplified or full—OPEN QUESTION | PROPOSED |
| Possessions | Shot clock ~12–14s for 3v3 | PROPOSED |
| Overtime | Short OT periods until winner | PROPOSED |
| Matchmaking | Skill + latency (+ party rules) | PROPOSED |
| Disconnect | Forfeit / bot fill policy TBD | OPEN QUESTION |

---

## Player controls

| Action | Intent |
|---|---|
| Movement | Analog locomotion; sprint stamina-gated |
| Dribbling | Speed vs control tradeoff; move packages by archetype |
| Passing | Ground / lob / dish; assist rewards teamwork |
| Shooting | Timing + contest + attribute hybrid |
| Dunking / finishing | Contact window + strength/vertical |
| Defense | Position, hand-up contest, bump |
| Stealing | Risk/reward reach; foul risk |
| Blocking | Jump timing + interior/perimeter splits |
| Rebounding | Box-out + vertical + positioning |
| Screens | Legal screen rules; griefing prevention |

**DECIDED:** Competitive outcomes must be **server-authoritative**.

---

## Basketball physics *(PROPOSED)*

- Deterministic-enough simulation for replays/anti-cheat audits
- Ball collision, bounce, rim interaction tuned for readability over hyper-realism in MVP
- Net/cloth cosmetics offline-priority

Exact physics stack depends on engine choice (still OPEN QUESTION).

---

## AI

| Use | Notes |
|---|---|
| Practice opponents | MVP |
| Fill disconnected slots | PROPOSED with clear labeling |
| Teammate AI (if needed) | Skill caps to reduce abuse |
| Coach suggestions | FUTURE |

AI difficulty should not beat fair human matchmaking integrity.

---

## Player attributes *(PROPOSED categories)*

### Physical
Speed · Acceleration · Strength · Vertical · Stamina

### Offense
Shooting · Finishing · Passing · Ball handling

### Defense
Perimeter defense · Interior defense · Steal · Block · Rebounding

### Mental
Basketball IQ · Clutch · Consistency · Teamwork

**OPEN QUESTION:** Numeric ranges, soft caps, diminishing returns. Do **not** treat rarity as a flat +99 to all stats.

---

## Player positions

PG · SG · SF · PF · C

**PROPOSED:** Position flexibility via secondary positions and badges; 3v3 lineups may use position tags loosely with chemistry rules.

---

## Player rarity

| Idea | Guidance |
|---|---|
| Tiers (e.g., Common → Legend) | PROPOSED naming TBD |
| Meaning | Visual prestige, drop rates, cosmetic flair |
| **Non-goal** | Rarity ≠ automatic competitive dominance (**DECIDED**) |

High rarity may unlock **potential ceilings** or cosmetics, but on-court power must remain trainable/skill-mediated. Exact model: OPEN QUESTION.

---

## Player generation

**PROPOSED entry paths:**

1. Starter packs / tutorial grants (anti-P2W tuned)
2. Academy graduation
3. Scouting discoveries / drafts
4. Marketplace acquisition
5. Limited events *(careful with supply)*
6. FUTURE: licensed athlete mirrors (only with real rights)

Supply governance is an economy concern.

---

## Player progression

| System | Intent | Status |
|---|---|---|
| XP / levels | Baseline growth | PROPOSED |
| Skills / caps | Specialize builds | PROPOSED |
| Training | Time/resource sinks | PROPOSED |
| Badges | Playstyle mastery | PROPOSED |
| Evolution / awakening | Rare breakthrough moments | FUTURE / careful |
| Chemistry | Lineup synergy | PROPOSED |

---

## Player careers

Career stats and milestones update after validated matches. Public career cards for scouting and marketplace trust. Career fields are sketched in the overview.

---

## Player aging *(PROPOSED / FUTURE)*

Optional long-term curve (peak → decline → mentor/coach role). **Not MVP.** If added, must preserve collectors’ lore and avoid griefing via forced decay abuse.

---

## Injuries *(PROPOSED)*

Light injury system for realism and roster management; must not feel like random punishment. Severity, duration, insurance cosmetics: OPEN QUESTION. Deferrable past MVP.

---

## Equipment

**PROPOSED:** Mostly cosmetic (shoes, sleeves, arena items). Performance gear if any must be tightly capped and transparent to avoid P2W. Prefer cosmetics-only for competitive integrity (**PROPOSED policy**).

---

## Clubs

Roster caps, roles (owner, GM, coach, players), branding, club XP. Deep facilities: expansion. Club depth is outlined in the overview.

---

## Academies

Youth development loops, drills, graduation. **Post-MVP / FUTURE relative to match MVP.**

---

## Scouting

Hidden potential, report accuracy vs scout skill, tryouts. Anti-bot essential. Post-core feature.

---

## Player contracts *(PROPOSED)*

Duration, wage in soft currency, release clauses, loan options. Legal-style complexity kept game-abstract. Ties to transfers.

---

## Transfers

List, bid, accept, cool-downs, club approval rules. Settlement may be off-chain plus on-chain for owned assets.

---

## Competitions & seasons

| Element | Notes |
|---|---|
| Seasons | Time-boxed ranked eras; rewards at close |
| Soft reset | Ranks may soft-reset; careers persist (**PROPOSED**) |
| Tournaments | Entry fees ≠ wagering unless explicitly designed & legally cleared |

---

## Rankings & leaderboards

MMR/Elo-like or Glicko-like (**OPEN QUESTION**). Leaderboards: wins, points, club trophies, fair-play score.

---

## Rewards

XP, soft currency, cosmetics, badges, seasonal accolades. Cash-like rewards only with legal review. No guaranteed APR language.

---

## Cosmetics

Skins, celebrations, court designs, club crests—primary ethical monetization path.

---

## Social features

Parties, club chat, reports/moderation, spectate (PROPOSED), shareable replays (PROPOSED).

---

## Esports *(FUTURE)*

Observer mode, tournament admin tools, anti-cheat hardening, broadcast HUD.

---

## MVP gameplay scope

**In:**

- Embedded wallet + owned on-chain player(s)
- Controllable basketball feel (move, shoot, pass, defend)
- Casual + ranked 3v3 using owned roster
- Basic progression (XP/levels/light training) on owned players
- Match history + simple career stats linked to assets
- Anti-cheat foundation (server authority)
- Basic analytics events
- Ownership sync / indexer path

**Out:**

- Full 5v5 sim
- Deep academies/scouting
- Complex club politics
- Injuries/aging
- Fungible token
- Wagering
- Licensed leagues
- On-chain live match simulation

Acceptance: “I own this player on-chain; matches feel good; ranked is fair; next goal after a match is clear.” Phasing is in the roadmap.

---

## Open questions

- Final MVP mode confirmation (3v3 vs alternate)
- Shooting timing vs stick aim emphasis
- Fouls/FT complexity for MVP
- Cross-play
- Input schemes (gamepad priority?)
