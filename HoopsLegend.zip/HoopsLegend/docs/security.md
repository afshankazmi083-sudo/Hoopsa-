# Security — HoopsLegend (working title)

## Document control

| Field | Value |
|---|---|
| Document ID | CR-DOC-009 |
| Title | Security |
| Project | HoopsLegend (working title) |
| Version | 1.1 |
| Status | Design draft |
| Classification | Internal / Confidential |
| Date created | 8 September 2026 |

Status tags: **DECIDED** · **PROPOSED** · **OPEN QUESTION** · **FUTURE** · **REJECTED**

Internal use only. Threat model for a **blockchain basketball** product. Sensitive — limit distribution.

---

## Security objectives

Protect accounts, **wallets**, funds, and **on-chain assets**. Keep ranked play honest. Stop bots and farming from eating the economy. Keep contracts and wallet flows tight. Be able to detect trouble, respond, and recover.

---

## Threat model

| Threat | Impact | Primary controls *(PROPOSED)* |
|---|---|---|
| Account takeover | Loss of progress/assets | MFA, session hardening, anomaly login |
| Credential theft | ATO | Passwordless/social options, breach detection |
| Wallet compromise | Asset theft | AA limits, session keys, clear signing UX |
| Smart contract exploits | Fund/asset loss | Audits, pause, least privilege |
| Cheating | Ranked integrity collapse | Server authority, detection, bans |
| Bots | Economy/ladder pollution | Challenges, behavior ML, device signals |
| Marketplace manipulation | Price distortion | Fees, rate limits, wash-trade detection |
| Fake assets | User fraud | Canonical mint roles, indexer verify |
| Tx replay | Double spend / confuse state | Nonces, idempotency |
| API abuse | Outage / scraping | Authz, WAF, rate limits |
| DDoS | Availability | CDN/edge, autoscaling, blackhole |
| Fraud / chargebacks | Revenue loss | Risk scoring, velocity limits |
| Money laundering | Legal risk | KYC/AML on rails, monitoring |
| Multi-accounting | Reward abuse | Graph detection, reward caps |
| Reward farming | Inflation | Match quality gates, caps |
| Collusion / match fixing | Ladder & prize integrity | Odd patterns, related-account graphs, review |

---

## Authentication *(PROPOSED)*

- Modern IdP patterns (email magic link / OAuth / optional passkeys)
- MFA for withdrawal and high-risk actions
- Short-lived access tokens + rotatable refresh
- Device session inventory & remote revoke

---

## Authorization

- RBAC for user/club/admin roles
- Principle of least privilege on service credentials
- Object-level checks (cannot modify others’ inventories)
- Admin actions dual-control for sensitive economy ops (**PROPOSED**)

---

## Wallet security

- Clear human-readable tx summaries
- Spending limits / session keys for game actions
- Phishing education in UX
- Separate hot/cold operational keys for minter/admin
- Incident runbook for compromised embedded wallets

---

## Smart contract security

| Practice | Status |
|---|---|
| External audit pre-mainnet market | DECIDED as requirement before public market |
| Pausability on market modules | PROPOSED |
| Timelock / multisig admin | PROPOSED |
| Formal test suites + fuzzing | PROPOSED |
| No unbounded approvals in reference UI | PROPOSED |

---

## Server authority

**DECIDED:** Competitive gameplay is server-authoritative because clients are untrusted. Clients may predict for feel; server validates movement, shot timing windows, ball possession, and scores.

---

## Anti-cheat

| Layer | Examples |
|---|---|
| Prevention | Authority, encrypted protocols where useful, obfuscation (limited value alone) |
| Detection | Stat anomalies, input timing impossibilities, memory-tamper signals (platform-dependent) |
| Response | Soft flags → ranked restrictions → bans; evidence retention |
| Process | Appeal path; false-positive review |

---

## Fraud prevention

- Deposit/withdrawal velocity limits
- Linking graphs (device, payment, chain address)
- Manual review queues for large withdrawals
- Chargeback playbooks

---

## Marketplace security

- Authenticated listings bound to ownership proofs
- Escrow/hold balances
- Wash-trade heuristics
- Pause switch
- Replay-safe settlement IDs

---

## Payment security

- PCI scope minimization via PSP
- Webhook signature verification
- Idempotent crediting
- Reconciliation jobs

---

## Rate limiting

Per-IP, per-account, per-endpoint budgets; stricter on auth, mint, withdraw, list.

---

## Data protection & privacy

| Topic | Approach *(PROPOSED)* |
|---|---|
| Encryption | TLS in transit; KMS for secrets at rest |
| PII minimization | Collect only needed fields |
| Retention | Defined schedules; match logs vs PII split |
| Rights requests | Export/delete workflows where legally required |
| Policy | Privacy policy + ToS before public launch |

Not a substitute for legal counsel.

---

## Logging & monitoring

- Security event pipeline (login failures, admin acts, pause triggers)
- Alerts on indexer lag, abnormal mint volume, withdraw spikes
- Immutable audit logs for admin

---

## Incident response *(PROPOSED)*

1. Detect → 2. Contain (pause market / freeze withdraw) → 3. Eradicate → 4. Recover → 5. Postmortem  
Comms templates for users; severity levels defined pre-launch.

---

## Contract audit strategy

- Audit before first public mint/market
- Re-audit on major upgrades
- Public report summary when safe

---

## Security testing

SAST/DAST in CI, dependency scanning, secrets scanning, threat modeling reviews each phase.

---

## Penetration testing

External pen-test before public launch (Phase 7 gate) and after major surface changes.

---

## Bug bounty *(PROPOSED)*

Launch post-beta or at public launch for app + contracts; scoped assets; payout policy.

---

## Disaster recovery

Align with [technical-architecture.md](technical-architecture.md): backups, key ceremony recovery, marketplace pause, match result repair tooling.

---

## Security principles

| Principle | Status |
|---|---|
| Assume client compromise | DECIDED |
| Least privilege | DECIDED |
| Defense in depth | DECIDED |
| Fail safe (pause > silent loss) | DECIDED |
| Privacy by design | PROPOSED |
| No security through obscurity alone | DECIDED |

---

## Open questions

- Anti-cheat vendor vs in-house mix
- MFA enforcement timing
- Data residency requirements by launch region
- Bug bounty provider
