# Vision — HoopsLegend (working title)

## Document control

| Field | Value |
|---|---|
| Document ID | CR-DOC-002 |
| Title | Vision |
| Project | HoopsLegend (working title) |
| Version | 1.1 |
| Status | Design draft |
| Classification | Internal / Confidential |
| Date created | 8 September 2026 |

Status tags: **DECIDED** · **PROPOSED** · **OPEN QUESTION** · **FUTURE** · **REJECTED**

Internal use only. Directional thinking for the team. Not a shipping promise, contract, or investment document.

---

## Vision statement

**DECIDED:** Build the leading **blockchain basketball** universe — where players are owned assets with real careers, clubs and markets run on transparent ownership, and competitive matches give those assets meaning.

---

## Mission

Ship a Web3-native basketball game where **on-chain ownership is the product backbone**, and basketball competition is the engine that creates performance, prestige, and demand for those assets.

Embedded wallets and gas abstraction exist so ownership is usable — not so blockchain can be skipped.

---

## Long-term objective

A durable **on-chain basketball economy** with:

- owned digital players bound to careers and competition
- clubs, academies, scouting, seasons, and transfers
- marketplace settlement and provenance users can trust
- skill-based matches (live sim off-chain; results and ownership on the product’s chain layer)
- optional paths into esports and real-world basketball later

We are not a traditional sports publisher “adding NFTs someday,” and we are not a token launch with a basketball skin.

---

## What success looks like

| From whose seat | We are doing well if… |
|---|---|
| Player | Owns roster on-chain; matches feel fair; careers feel earned |
| Community | Clubs and rivalries form around owned teams and seasons |
| Club | On-chain org identity + roster craft matter more than flip spam |
| Business | Revenue from marketplace, assets, cosmetics, memberships — not endless mint hype alone |
| Web3 / chain | Ownership, transfers, and provenance are daily product surfaces; chain choice and contracts are first-class engineering |

---

## Rough 3-year picture (PROPOSED)

| Area | Aim |
|---|---|
| Chain | Production ownership + marketplace on a chosen network; solid wallet UX |
| Assets | Players (and selected items) owned on-chain with career linkage |
| Gameplay | Solid core modes; ranked seasons that feed asset prestige |
| Orgs | Clubs live; basic academies live |
| Economy | Soft + premium as needed; on-chain market for core assets; no mandatory fungible token |
| Community | Clubs, tournaments, collectors, creators |

Directional only. No headcount or date promises here.

---

## Rough 5-year picture (PROPOSED / mostly FUTURE)

| Area | Possible |
|---|---|
| Esports | Circuit around owned competitive rosters |
| Real-world | Optional training/event bridges — FUTURE |
| Licensing | Only if we have real deals — FUTURE / OPEN QUESTION |
| Global | More regions, local leagues, localization |
| Creators | Tools for clubs, casters, academies — FUTURE |

Do not promise licensed IP, user scale, or token upside.

---

## Strategic pillars

| # | Pillar | Status |
|---|---|---|
| 1 | Blockchain ownership of basketball assets | DECIDED |
| 2 | Competitive basketball that creates career value | DECIDED |
| 3 | Persistent careers tied to owned players | DECIDED |
| 4 | Seasons, leagues, tournaments | DECIDED |
| 5 | Sustainable, non-P2W economy + marketplace | DECIDED |
| 6 | Global basketball + collector community | DECIDED (aspiration) |

---

## What we refuse to become

| Anti-goal | Why |
|---|---|
| Traditional game with “crypto optional later” | Misrepresents the product; wrong hiring and architecture |
| Pure flip / speculation platform | Kills fairness and retention |
| Token-first product | Pulls incentives away from play and ownership utility |
| Pay-to-win ladder | Competitive integrity dies |
| On-chain live match simulation | Latency, cost, bad UX (engineering limit — not “chain is optional”) |
| Metaverse land for the pitch deck | Scope without product value |
| Default gambling product | Legal and trust risk |

---

## Still open

- Final name and look
- Chain selection (core workstream)
- Wallet / AA stack
- How deep real-world basketball goes (if at all)
- Launch jurisdictions and regulation
- Whether we chase licensed IP at all
