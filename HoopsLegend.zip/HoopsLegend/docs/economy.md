# Economy — HoopsLegend (working title)

## Document control

| Field | Value |
|---|---|
| Document ID | CR-DOC-005 |
| Title | Economy |
| Project | HoopsLegend (working title) |
| Version | 1.1 |
| Status | Design draft |
| Classification | Internal / Confidential |
| Date created | 8 September 2026 |

Status tags: **DECIDED** · **PROPOSED** · **OPEN QUESTION** · **FUTURE** · **REJECTED**

Internal / confidential. Do not circulate. Not legal, tax, or financial advice.

Anything that touches payments, withdrawals, prizes, or wagering needs a real lawyer before we treat it as final. This file is product design for a **blockchain basketball** economy.

---

## Economy objectives

Fund and sustain an **on-chain ownership + marketplace** economy. Keep progression fun without forcing pay-to-win. Let people trade developed talent without turning the game into a pure flip pit. Fight inflation, bots, and collusion. Protect ranked integrity.

---

## Economic principles

| Principle | Status |
|---|---|
| Sustainable | DECIDED |
| Transparent | DECIDED |
| Easy to understand | DECIDED |
| Hard to inflate | DECIDED |
| Hard to exploit | DECIDED |
| Fair / not automatically pay-to-win | DECIDED |
| No mandatory fungible token for MVP | DECIDED |

---

## Currencies

### Soft currency *(PROPOSED name: “Court Bucks” / TBD)*

| Use | Earn | Sink |
|---|---|---|
| Training, basic entry, repairs/consumables (if any), club upkeep basics | Gameplay, achievements, daily/seasonal caps | Training, cosmetics lite, fees |

### Premium currency *(PROPOSED)*

| Use | Source |
|---|---|
| Cosmetics, convenience (XP boosts with caps), battle pass style tracks | Fiat purchase (and possibly promo grants) |

**PROPOSED policy:** Premium must not buy raw ranked power. Boosts, if any, are time-limited and capped.

### Blockchain assets

Non-fungible (or semi-fungible) items representing ownership: eligible players, limited cosmetics, club trophies, etc.

**DECIDED:** A fungible governance/utility token is **not assumed**.

---

## Deposits

| Type | Description | Status |
|---|---|---|
| Fiat deposit | Card/APM → account balance or direct purchase | PROPOSED |
| Crypto deposit | Supported assets → custodial/embedded balance or direct pay | OPEN QUESTION |
| Wallet balance | Ledger of spendable funds | PROPOSED |
| Payment provider | Stripe-like / regional PSPs | OPEN QUESTION |
| Processing | Idempotent tx, reconciliation, fraud checks | DECIDED as requirement |

**DECIDED:** Deposit ≠ wager. Deposits fund purchases and eligible economic actions.

---

## Purchases *(PROPOSED examples)*

- Cosmetics and celebration packs
- Player acquisition where fair (starter, not god-tier power)
- Season / premium passes
- Club cosmetic features
- Convenience items with competitive caps

---

## Competition fees

| Fee type | Meaning | Distinction |
|---|---|---|
| Ranked queue fee | Optional soft-currency toll | Not a bet against another user |
| Tournament entry | Access + prize funding from **published** pool rules | Still may need prize-competition legal review |
| Wagering stake | User-vs-user stake | **OPEN QUESTION**; **legal review required**; not default |

---

## Rewards

| Source | Examples | Notes |
|---|---|---|
| Gameplay | Soft currency, XP, badges | Cap farm rates |
| Season | Cosmetics, titles | Prefer non-inflationary |
| Tournaments | Published prize table | Legal review if cash-like |
| Achievements | One-time grants | Anti-multi-account |
| Referrals | Careful, abuse-prone | Optional FUTURE |

**REJECTED:** Promising fixed ROI, “salaries,” or passive yield as a product pillar.

---

## Withdrawal *(PROPOSED concept)*

Eligible balances (e.g., marketplace proceeds under policy) may be withdrawable subject to:

- identity verification where required
- velocity limits and holds
- fraud review
- geographic restrictions
- clear ToS

**OPEN QUESTION:** Which balances are withdrawable vs spend-only.

```mermaid
flowchart LR
  A[Eligible balance] --> B[Request withdrawal]
  B --> C[Risk / KYC checks]
  C -->|Pass| D[Payout rail]
  C -->|Fail| E[Reject / manual review]
```

---

## Marketplace

| Function | Notes |
|---|---|
| Listings | Price, duration, asset binding |
| Purchases | Atomic swap of asset ↔ currency/funds |
| Fees | Protocol/platform fee (**PROPOSED** %) — exact TBD |
| Transfers | Gift/trade rules; anti-fraud |
| Cancellations | Seller cancel before fill |
| Price discovery | Open market; optional floor displays |

Wash trading, bid shading rings, and spoofing: mitigations in [security.md](security.md).

---

## Economic sinks

| Sink | Purpose |
|---|---|
| Training | Progression cost |
| Upgrades / badges crafts | Specialization cost |
| Club infrastructure | Org progression |
| Tournament access | Competitive demand |
| Cosmetics | Voluntary spend |
| Marketplace fees | Revenue + friction on spam |
| Listing fees | Reduce junk listings |
| Name changes / services | Minor sinks |

---

## Economic sources

| Source | Notes |
|---|---|
| Gameplay rewards | Primary engagement fuel—must be capped |
| Tournaments | Recirculate fees carefully |
| Achievements | Sparse |
| Sales (primary) | Studio revenue |
| Club activity bonuses | Careful with inflation |

---

## Anti-inflation mechanisms *(PROPOSED)*

- Soft currency earn caps (daily/weekly)
- Diminishing returns on repetitive farming
- Season sinks timed with reward emissions
- Prefer cosmetic sinks over power inflation
- Supply schedules for minting new players

---

## Anti-farming mechanisms *(PROPOSED)*

- Match quality scoring (AFK, intentional feed)
- Reward eligibility tied to fair-play
- Cooldowns on claim actions
- Device/account graph analysis

---

## Anti-bot mechanisms

Server-authoritative play, challenge/response, anomaly detection, hardware attestation where appropriate (platform-dependent). See [security.md](security.md).

---

## Treasury

**PROPOSED:** Platform treasury accumulates marketplace fees, premium sales share, and partnership income. Used for ops, prize funding (published), and ecosystem health—not opaque “token buybacks” theater.

On-chain treasury only if Web3 marketplace live; governance model OPEN QUESTION (likely centralized at launch).

---

## Revenue model *(PROPOSED)*

| Stream | Notes |
|---|---|
| Cosmetic / pass purchases | Primary ethical stream |
| Marketplace fees | Secondary |
| Premium memberships | Convenience + cosmetics |
| Tournament services | Hosting tools—not unregulated betting |
| Partnerships / brand | FUTURE |
| Licensing | FUTURE / OPEN QUESTION |

No invented revenue forecasts.

---

## Token strategy

### Does the game need a fungible token?

**DECIDED for MVP/near-term: No.**

Reasons:

- Soft + premium currencies cover gameplay and monetization
- NFTs (or equivalent) can cover scarce ownership without a fungible speculative asset
- Tokens introduce securities, listings, and incentive distortion risks

### If reconsidered later, minimum requirements before implementation

1. Clear utility that soft/premium cannot provide
2. Legal analysis (securities, promotions, jurisdictions)
3. Emission model resistant to mercenary capital
4. UX that does not force token holding to play
5. Documented failure modes and kill-switch governance

**Do not invent supply, allocation %, or APY figures as decisions.**

---

## Financial / legal risk flags *(for specialist review)*

| Area | Why flagged |
|---|---|
| Wagering / gambling | Stake-based modes |
| Prize competitions | Cash or cash-like prizes |
| Securities | Any fungible token / investment framing |
| Money transmission | Deposits/withdrawals, stored value |
| KYC/AML | Fiat and crypto rails |
| Payment processing | PCI, chargebacks |
| Geographic restrictions | Licensing variance |
| Age restrictions | Minors + payments + chat |
| Consumer protection | Loot box-like mechanics if used |

Loot boxes / randomized paid rewards: **OPEN QUESTION**; if used, disclose odds and review regional rules.

---

## Consistency notes

- Matches the on-chain ownership + marketplace approach in the Web3 doc
- Power sales constrained by game design
- Roadmap puts wallets + owned players in MVP; marketplace hardens next

---

## Open questions

- Soft/premium currency names and FX
- Withdrawable vs closed-loop balances
- Exact marketplace fee schedule
- Payment and KYC vendors
- Randomized reward policy
- Any jurisdiction-specific launch blockers
