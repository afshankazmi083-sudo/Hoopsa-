# Product Overview — HoopsLegend (working title)

## Document control

| Field | Value |
|---|---|
| Document ID | CR-DOC-001 |
| Title | Product Overview |
| Project | HoopsLegend (working title) |
| Version | 1.1 |
| Status | Design draft |
| Classification | Internal / Confidential |
| Date created | 8 September 2026 |

Status tags: **DECIDED** · **PROPOSED** · **OPEN QUESTION** · **FUTURE** · **REJECTED**

Internal use only. Design notes for the team — not a contract, investment offer, or legal advice. Do not share outside the project without approval.

---

## Product overview

HoopsLegend is a **blockchain-based basketball game**. Digital players are owned assets with careers. You mint or acquire players, train, compete, run clubs and academies, chase seasons, and trade on a marketplace whose settlement and ownership live on-chain.

**DECIDED:** Blockchain ownership, provenance, and marketplace rails are **core product surfaces**. Competitive basketball is how those assets earn history and demand — not a traditional game with crypto bolted on later.

Every account path includes wallet capability (embedded by default). Live match simulation stays off-chain for latency and anti-cheat; that is an engineering split, not “chain is optional.”

---

## Problem

These are team observations and hypotheses, not market stats. Anything that needs outside research is tagged **Needs verification**.

| Category | What we think is weak |
|---|---|
| Traditional basketball games | Great play; no true portable ownership of players/economy |
| Fantasy sports | Seasonal hook; no owned digital athletes you actually play with |
| Thin NFT sports games | Ownership without enough competitive basketball *(Needs verification per title)* |
| Web3 games in general | Wallet friction, fuzzy utility, inflation, pay-to-win smell |
| Sports management games | Deep systems; rarely true on-chain portable ownership |

**Problem (PROPOSED):** The market splits into great basketball with no ownership, or ownership with weak basketball. We build **blockchain basketball** — owned players whose value is fed by real competition.

---

## Solution

| Gap | How we intend to answer it |
|---|---|
| Crypto bolted onto a sports game | Product is Web3-native from day one: wallets, owned players, chain settlement |
| Thin NFT sports | Real competitive basketball attached to owned assets |
| Static collectibles | Careers, stats, milestones, club history on owned players |
| Pay-to-win smell | Skill + soft progression; premium/cosmetics, not bought rank |
| One role only | Play, coach, scout, club/academy, collect, fan |
| Opaque markets | On-chain ownership + clear marketplace settlement |
| Short retention | Seasons, clubs, academies, rivalries, long careers |

---

## Product philosophy

| Principle | In plain terms |
|---|---|
| **Blockchain basketball first** | Ownership and trade of players are the product backbone |
| **Competition creates asset meaning** | Matches and seasons feed careers and prestige |
| **Fair ladders** | Anti-cheat; money does not auto-win ranked |
| **Progression** | Training, badges, careers reward time and skill |
| **Sustainable on-chain economy** | Marketplace + sinks; no mandatory fungible token for MVP |
| **Usable Web3 UX** | Embedded wallets, gas abstraction, plain language — chain is required, friction is not |

Same intent as the vision doc.

---

## User types

| Type | Description | MVP priority |
|---|---|---|
| **Player** | Controls athletes in matches; climbs ranks | Core |
| **Coach** | Lineups, tactics, training plans *(depth PROPOSED)* | Partial MVP → expand |
| **Scout** | Discovers prospects; evaluates potential | Post-core / Phase 8 |
| **Club owner** | Brand, roster, competition entry | Post-MVP expansion |
| **Academy owner** | Develops youth talent pipelines | FUTURE relative to MVP |
| **Collector** | Values rarity + career lore | Marketplace phase |
| **Fan** | Follows clubs/players; social presence | Progressive |
| **Competitive / esports** | High-skill ranked and tournament play | Ranked in MVP path; formal esports FUTURE |

---

## Core loop

```mermaid
flowchart LR
  A[Discover] --> B[Build]
  B --> C[Train]
  C --> D[Play]
  D --> E[Progress]
  E --> F[Compete]
  F --> G[Earn]
  G --> H[Trade]
  H --> I[Improve]
  I --> C
```

| Stage | Description |
|---|---|
| **Discover** | Obtain or scout players; evaluate attributes and potential |
| **Build** | Form squads / join clubs; set identity and roles |
| **Train** | Improve skills via drills, XP, coaching *(exact formulas PROPOSED)* |
| **Play** | Skill-based matches (casual → ranked) |
| **Progress** | Levels, badges, chemistry, career stats |
| **Compete** | Leagues, tournaments, seasons |
| **Earn** | Soft rewards, cosmetics, competitive prizes *(not financial promises)* |
| **Trade** | Transfers and marketplace listings for eligible assets |
| **Improve** | Reinvest into training, roster, club infrastructure |

---

## Long-term loop

Users return because:

- Seasons reset competitive context while careers persist
- Clubs create social obligation and rivalry
- Academies and scouting create long development arcs
- Marketplace and transfers create strategic roster craft
- Cosmetics and achievements create identity
- Ranked/esports paths create mastery goals

---

## Basketball universe

**PROPOSED:** A persistent shared universe with:

- Digital players as first-class citizens
- Clubs as enduring organizations
- Academies as talent funnels
- Seasons as time structure
- Official competitions as prestige layers
- Community events and creator-driven tournaments (later)

The universe is **game-world first**; real-world bridges are FUTURE.

---

## Digital player concept

Players are **persistent digital entities**, not disposable match avatars.

They carry:

- identity and visuals
- attributes and tendencies
- ownership / contract state
- career record
- club affiliations over time

**DECIDED:** Performance and history should influence perceived value more than mint-date hype alone.

---

## Player career

**PROPOSED career data** (fields not finalized):

| Category | Examples |
|---|---|
| Performance | Points, assists, rebounds, steals, blocks, FG% |
| Outcomes | Wins, losses, series results |
| Prestige | Championships, awards, all-star selections *(naming TBD)* |
| Affiliations | Clubs, academies, coaches |
| Milestones | Debut, 1000 points, clutch records |

Exact scoring formulas and award rules: OPEN QUESTION pending design playtests. Mechanics and fields are still open; see game design and data model.

---

## Clubs

| Aspect | Intent |
|---|---|
| Ownership | User- or org-owned club entities |
| Management | Roster, staff roles, branding |
| Identity | Name, colors, crest, home court cosmetics |
| Competition | Enter leagues/tournaments |
| Progression | Club level/reputation *(PROPOSED)* |

Clubs are a major retention system; full depth is post-MVP (see roadmap).

---

## Academies

Academies develop prospects before (or alongside) first-team careers.

**PROPOSED capabilities:** intake, training programs, graduation/promotion to clubs, reputation for producing talent.

**MVP:** Not required. Marked FUTURE relative to core match MVP.

---

## Scouting

Scouting is **talent discovery**: evaluating hidden potential, watching performances, and acquiring rights or recommendations under fair rules.

**PROPOSED:** Information asymmetry that skill and attention can overcome—not pure paywalls.

Risks: botting, insider farming—see security and economy docs.

---

## Transfers

Player movement between owners/clubs via:

- negotiated transfers
- marketplace listings
- contract expirations / free agency *(PROPOSED)*

Value should reflect **development + performance + scarcity**, not only rarity tags. Details in [economy.md](economy.md) and [web3.md](web3.md).

---

## Competitions

| Format | Role | Status |
|---|---|---|
| Ranked games | Ladder / MMR | PROPOSED for MVP path |
| Casual | Low-stakes practice | PROPOSED |
| Leagues | Structured club/season play | Post-MVP |
| Tournaments | Bracket events | Progressive |
| Seasons | Time-boxed competitive eras | DECIDED as concept |
| Championships | Peak prestige | FUTURE/expansion |

---

## Social / community systems

**PROPOSED:** Friends, club chat, spectating, highlight sharing, creator tools (later), community tournaments.

Esports ops and formal circuits: FUTURE.

---

## Marketplace

Secondary market for eligible assets (players, cosmetics, club items as designed).

Includes listings, purchases, fees, cancellations, and provenance display. Covered in the economy doc.

---

## Deposits and withdrawals

**DECIDED:** Deposits are **not** automatically gambling or betting.

| Concept | Meaning | Notes |
|---|---|---|
| Deposit | Fund in-game wallet / balance (fiat or crypto) | Payment processing; KYC/AML may apply |
| Purchase | Buy cosmetics, passes, assets | Consumer purchase |
| Competition fee | Entry cost for events | Distinguish from wagering |
| Rewards | Gameplay or event prizes | Not a yield promise |
| Marketplace tx | Peer asset trade | Fees apply |
| Withdrawal | Cash-out of eligible balances | Limits, reviews, legal constraints |
| Wagering | Stake vs stake / betting mechanics | **OPEN QUESTION**; **requires legal review** before any design commitment |

Any prize competition or wagering-like mechanic must be labeled for specialist legal review (jurisdictions, age, KYC, gambling law). This document does **not** provide legal advice.

---

## Web3 role

**DECIDED:** This is a blockchain basketball product. Chain is required for:

- ownership of digital players (and other selected assets)
- provenance users can verify
- marketplace settlement
- portable, user-controlled assets

**Also DECIDED (engineering):** Chain does **not** run live physics, matchmaking, MMR ticks, or every XP update. Those stay off-chain so matches stay fast and fair. Off-chain play does not mean optional blockchain.

More detail in the Web3 doc.

---

## Future possibilities *(FUTURE)*

| Idea | Notes |
|---|---|
| Real-world basketball integration | Activity → digital progression bridges |
| AI coaching | Training recommendations, film breakdown |
| Computer vision | Form analysis from real play |
| Real-world events | Live activations, campus leagues |
| Esports | Formal circuit, broadcast tools |
| Licensed athletes / teams | Only with real agreements—do not invent |

---

## MVP boundary

**MVP must include (blockchain basketball core):**

| In MVP | Why |
|---|---|
| Embedded wallet (create/recover) | Ownership path is product-critical |
| Player assets on-chain (mint/bind) | Blockchain basketball identity |
| Ownership sync into game roster | You play what you own |
| Basic competitive 3v3 + progression | Assets need competitive meaning |
| Indexer + admin pause | Ops reality for a chain product |

**MVP should NOT attempt:**

| Out of MVP scope | Reason |
|---|---|
| Full academy simulation | After core ownership + play loop |
| Deep scouting meta | Needs population |
| Full club politics | Expansion |
| Fungible token launch | Not justified for MVP |
| Licensed NBA/real teams | No invented partnerships |
| On-chain live match simulation | Latency / cost anti-pattern |
| Wagering | Legal gate |
| Metaverse hubs / land | REJECTED for near-term |
| DAO / lending / bridges | Out of scope early |

**MVP should prove:** users own players on-chain; matches feel good with those players; ranked is fair; marketplace path is designed (basic list/buy can land in MVP or immediately after — see roadmap); economy does not break.

---

## Open questions

- Exact career award taxonomy
- Club vs solo competitive priority at launch
- Geographic and regulatory launch set
- Whether any prize pools are cash-equivalent
- Chain and wallet vendor selection (core hiring/architecture workstream)
