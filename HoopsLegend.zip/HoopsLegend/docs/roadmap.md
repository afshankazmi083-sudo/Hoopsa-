# Roadmap — HoopsLegend (working title)

## Document control

| Field | Value |
|---|---|
| Document ID | CR-DOC-010 |
| Title | Roadmap |
| Project | HoopsLegend (working title) |
| Version | 1.1 |
| Status | Design draft |
| Classification | Internal / Confidential |
| Date created | 8 September 2026 |

Status tags: **DECIDED** · **PROPOSED** · **OPEN QUESTION** · **FUTURE** · **REJECTED**

Internal use only. Planning aid. No delivery dates are promised in this document.

Phases are capability gates, not calendar commitments. Timing depends on headcount, engine choice, and chain selection.

---

## MVP definition (PROPOSED)

**Blockchain basketball MVP:** A user creates an account with an **embedded wallet**, owns at least one **on-chain player asset**, plays **3v3** casual/ranked under server authority, earns progression tied to that owned player, and sees career/match history. Basic marketplace path is in MVP or the immediate next gate.

**Out of MVP on purpose:** deep clubs/academies/scouting, fungible token, wagering, licensed IP, on-chain live match simulation, DAO/lending/bridges.

---

## Phase 0 — Research & Product Design

| | |
|---|---|
| **Objective** | Lock blockchain-basketball identity and design sources of truth |
| **Features** | Concept, GDD, economy, **Web3 as core architecture**, tech plan, legal flags |
| **Deliverables** | This documentation set; decision log in README |
| **Dependencies** | Stakeholder review |
| **Risks** | Sliding back into “crypto optional later” framing |
| **Acceptance** | Docs consistently describe blockchain basketball first |
| **Exit** | Approval to prototype play **and** chain ownership slice |

**Status:** Docs updated for blockchain-first identity.

---

## Phase 1 — Dual prototype (Feel + Chain)

| | |
|---|---|
| **Objective** | Prove (a) basketball feels fun and (b) ownership/wallet path is real |
| **Features** | Court, move, shoot, pass, defense, simple AI **and** embedded wallet spike, testnet player mint/bind, ownership read into a stub inventory |
| **Deliverables** | Play vertical slice; chain ownership spike; notes from both |
| **Dependencies** | Engine spike; chain shortlist |
| **Risks** | Feel not fun; wallet UX dead-end; wrong chain |
| **Acceptance** | “One more game” internally **and** “I own this player on-chain” demo works |
| **Exit** | Greenlight combined MVP |

---

## Phase 2 — Blockchain basketball MVP

| | |
|---|---|
| **Objective** | Closed-ready loop: **own → play → progress** |
| **Features** | Accounts + embedded wallets, player assets on-chain, ownership sync, lineups, matchmaking, matches, rankings, career basics, soft economy hooks, analytics, anti-cheat foundation, indexer |
| **Deliverables** | Staging build; admin pause for contracts; match integrity pipeline |
| **Dependencies** | Phase 1 dual prototype; chain ADR draft |
| **Risks** | Cheat gaps; ownership desync; progression imbalance |
| **Acceptance** | Ranked match with owned on-chain player; ownership survives restart; fair play baseline |
| **Exit** | Ready for marketplace + economy hardening |

---

## Phase 3 — On-chain marketplace & economy

| | |
|---|---|
| **Objective** | Trade and sustain the blockchain economy |
| **Features** | Marketplace list/buy on-chain, fees, deposits/payments as designed, rewards/sinks, balancing tools, provenance UI |
| **Deliverables** | Audited market contracts (or audit gate); ledgers; dashboards |
| **Dependencies** | Legal review on payments/withdrawals; Phase 2 ownership stable |
| **Risks** | Inflation; fraud; regulatory; wash trading |
| **Acceptance** | End-to-end trade of a player asset; caps work; no P2W power sales |
| **Exit** | Ready for closed alpha |

---

## Phase 4 — Chain hardening & advanced provenance

| | |
|---|---|
| **Objective** | Production-grade Web3 ops (not “introduce Web3”) |
| **Features** | Gas abstraction polish, recovery flows, attestation/provenance expansions, club assets (as scoped), reorg/ops runbooks, pen-test fixes on wallet/market surface |
| **Deliverables** | Hardened contracts + indexer SLOs; wallet UX polish |
| **Dependencies** | Phase 3 market live in staging |
| **Risks** | Key loss; contract bugs; congestion |
| **Acceptance** | Non-expert can complete own/trade flows; incident pause tested |
| **Exit** | Alpha with full blockchain basketball loop |

---

## Phase 5 — Closed Alpha

| | |
|---|---|
| **Objective** | Validate ownership + play + market with limited users |
| **Features** | Invite-only; feedback tools; live-ops light |
| **Deliverables** | Metrics for retention, match quality, wallet success, trade volume health |
| **Dependencies** | Phases 2–4 as scoped |
| **Risks** | Small sample; server/chain cost |
| **Acceptance** | Thresholds TBD (**OPEN QUESTION**) |
| **Exit** | Beta go/no-go |

**Test audience (PROPOSED):** Basketball players **and** Web3-native users; internal + design partners.

---

## Phase 6 — Beta

| | |
|---|---|
| **Objective** | Scale population; harden security & economy |
| **Features** | Broader invites; seasons v1; matchmaking improvements; security fixes |
| **Deliverables** | Public beta candidate; support playbooks |
| **Dependencies** | Alpha exit |
| **Risks** | Economy break; toxicity; chain load |
| **Acceptance** | Stability SLOs; major exploits closed |
| **Exit** | Launch readiness review |

---

## Phase 7 — Public Launch

| | |
|---|---|
| **Objective** | Open access in approved regions |
| **Features** | Marketing as **blockchain basketball**; support; live season; bug bounty (**PROPOSED**) |
| **Deliverables** | Production launch checklist |
| **Dependencies** | Legal ToS/privacy; payments; security gates; audits |
| **Risks** | Launch load; PR/regulatory |
| **Acceptance** | Checklist signed; rollback/pause plan tested |
| **Exit** | Steady-state live ops |

---

## Phase 8 — Expansion

| | |
|---|---|
| **Objective** | Deepen the blockchain basketball ecosystem |
| **Features (FUTURE / PROPOSED)** | Clubs depth, academies, advanced scouting, esports, real-world integrations, licensing (only if real), creator tools, i18n |
| **Deliverables** | Feature epics with ADRs |
| **Dependencies** | Healthy live ownership + play economy |
| **Risks** | Dilution; legal for real-world/licensing |
| **Acceptance** | Per-epic metrics |
| **Exit** | Continuous |

---

## Phase summary

```mermaid
flowchart LR
  P0[0 Design] --> P1[1 Feel + Chain spike]
  P1 --> P2[2 Own + Play MVP]
  P2 --> P3[3 Market + Economy]
  P3 --> P4[4 Chain harden]
  P4 --> P5[5 Alpha]
  P5 --> P6[6 Beta]
  P6 --> P7[7 Launch]
  P7 --> P8[8 Expand]
```

**DECIDED:** Blockchain ownership is in the MVP path. We do not wait until “after a normal sports game ships” to add chain.

---

## Post-MVP themes

1. Marketplace depth and economic safety
2. Seasonality and social retention on owned rosters
3. Clubs → academies → scouting
4. Esports / real-world as justified
5. Advanced provenance and collector features

---

## Long-term roadmap

Aligned with vision: durable **on-chain** careers and club culture; optional real-world bridges; no token-first pivot.

---

## Roadmap risks

| Risk | Mitigation |
|---|---|
| Docs/hiring imply chain is optional | Blockchain-first language; chain in Phase 1–2 |
| Building play with no ownership | Dual prototype gate |
| Legal blockers on withdrawals/prizes | Early counsel; feature flags |
| Engine or chain redo | Early spikes |
| P2W under monetization pressure | Written economy principles |

---

## Open questions

- Numeric alpha/beta KPIs (include wallet success + ownership retention)
- Exact marketplace timing: end of Phase 2 vs Phase 3
- Regional launch sequence
- Staffing: blockchain engineers required from Phase 1

---

## Future documentation *(not created now)*

API specs, contract ADRs, art bible, legal memos, live-ops runbooks, esports ops, localization plans.
