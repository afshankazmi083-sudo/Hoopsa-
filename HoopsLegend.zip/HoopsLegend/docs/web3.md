# Web3 — HoopsLegend (working title)

## Document control

| Field | Value |
|---|---|
| Document ID | CR-DOC-006 |
| Title | Web3 |
| Project | HoopsLegend (working title) |
| Version | 1.1 |
| Status | Design draft |
| Classification | Internal / Confidential |
| Date created | 8 September 2026 |

Status tags: **DECIDED** · **PROPOSED** · **OPEN QUESTION** · **FUTURE** · **REJECTED**

Internal use only. **Core architecture** for a blockchain basketball product. Chain choice is still open — do not treat any network as locked.

---

## Web3 objectives

**DECIDED:** HoopsLegend is a blockchain-based basketball game. Web3 is not an optional plugin.

1. Make **player (and selected asset) ownership** a primary product surface.
2. Provide **provenance** for owned careers and scarce items.
3. Settle **marketplace trades** on-chain.
4. Keep **live matches** fast via off-chain simulation (engineering necessity).
5. Ship **embedded wallets + gas abstraction** so ownership is usable for non-experts — without making chain skippable.

**DECIDED:** Blockchain defines the product category. Basketball competition gives owned assets meaning.

---

## What belongs on-chain *(PROPOSED)*

| Candidate | Rationale | MVP? |
|---|---|---|
| Ownership of player assets | Product identity | **Yes** |
| Marketplace settlement | Transparent trade | **Yes / early** |
| Club ownership assets | Org identity | Progressive |
| Scarce cosmetics / trophies | Collectible authenticity | Progressive |
| Selected achievement attestations | Provenance (batched) | Later |

Not every XP tick or badge needs a mint. Core players and trades do.

---

## What stays off-chain *(DECIDED — engineering)*

| System | Reason |
|---|---|
| Gameplay / physics | Latency & cost |
| Matchmaking | Real-time |
| Live match state | Ephemeral |
| AI | Compute |
| Chat / social | Moderation & speed |
| Soft currency high-frequency ledger | Cost / speed (may bridge summaries later) |
| Ranked MMR | Integrity & update rate |

Off-chain here means **how we run matches**, not that users can ignore blockchain ownership.
---

## Wallet architecture *(PROPOSED)*

| Model | Role |
|---|---|
| Embedded / in-app wallet | **Default for all users** — required ownership path |
| External wallets | Power users (WalletConnect-style) |
| Account abstraction | Gas sponsorship, session keys, recovery |
| Recovery | Social/email recovery where product- and legally-safe |
| Custody clarity | Prefer non-custodial embedded with recovery; any custodial balance called out in ToS |

**DECIDED:** Wallet capability is part of account creation / onboarding for the product. UX should feel simple; chain participation is not optional for owning players.

**OPEN QUESTION:** Wallet vendor / AA stack.

---

## Asset architecture *(PROPOSED)*

| Asset class | Notes |
|---|---|
| Player NFTs | Bind to off-chain career ID; metadata URI + frozen career snapshot strategy TBD |
| Cosmetic NFTs | Optional; many cosmetics may remain off-chain entitlements |
| Club assets | Ownership / governance light |
| Trophies | Season prestige; limited mint |
| Limited collectibles | Events; supply caps published |

**Metadata principle:** Competitive stats authoritative off-chain; on-chain metadata should not become a cheat surface.

---

## Player asset lifecycle

```mermaid
flowchart LR
  M[Mint / Grant] --> O[Own]
  O --> D[Develop off-chain]
  D --> C[Compete]
  C --> H[Build history]
  H --> T[Transfer / Trade]
  T --> R[Retire / Archive]
```

| Stage | On-chain? | Off-chain? |
|---|---|---|
| Mint/grant | Often yes for scarce | Tutorial grants may start custodial/off-chain then bridge |
| Develop | No | Yes |
| Compete | No | Yes |
| History | Optional attest | Yes (canonical) |
| Transfer | Yes if NFT | Escrow/market services |
| Retire | Burn/lock optional | Archive career |

---

## Smart contracts *(categories only — no implementation)*

| Category | Purpose |
|---|---|
| Asset collection | ERC-721/1155-like player/cosmetic collections |
| Marketplace | List, buy, cancel, fee routing |
| Royalty / fee module | Optional; **not mandatory** |
| Access / roles | Admin, minter, pauser |
| Allowlists / launches | Controlled supply events |
| Attestation registry | Optional achievement proofs |

**REJECTED for MVP:** Complex DeFi (lending player NFTs, yield farms).

---

## Marketplace contracts

Atomic purchase flows; escrow listings; fee recipient; pause switch; reentrancy-safe patterns (engineering requirement). Indexer consumes events for UX.

---

## Ownership

Canonical owner = blockchain owner for bridged assets. Game server mirrors ownership via indexer; disputes resolved by chain state for on-chain assets.

Dual-ledger risks during bridging: design explicit state machine (OPEN QUESTION details).

---

## Royalties / fees

**PROPOSED:** Platform fee on trades. Creator royalties optional and jurisdiction/marketplace-policy dependent—**do not assume enforceable royalties everywhere**.

---

## Blockchain selection criteria *(OPEN QUESTION — no chain locked)*

Evaluate candidates on:

| Criterion | Weight guidance |
|---|---|
| Cost per common UX action | High |
| Throughput / finality UX | High |
| Gaming tooling & wallets | High |
| Security / battle-tested infra | High |
| Ecosystem liquidity for users | Medium |
| Decentralization ethos | Medium |
| Developer experience | High |
| Compliance posture / OFAC tooling | Medium-High |

Document a future ADR before locking. Candidates may include major L2s and gaming-focused chains—**Requires research**, no premature pick.

---

## Blockchain indexing

**PROPOSED:** Dedicated indexer (custom or hosted) for transfers, listings, mints → game DB projections. Reorg handling mandatory.

---

## Transaction UX

- Clear previews of asset + fee
- Human-readable errors
- Progress states (submitted → confirmed)
- Avoid interrupting matches for chain txs

---

## Gas abstraction *(PROPOSED)*

Sponsor gas for first-time mint/claim/list where economically viable; rate-limit abuse. Users may pay gas when using external wallets.

---

## Security (Web3-specific)

- Audits before mainnet marketplace
- Pause & upgrade transparency
- Multisig / timelock for admin
- No unlimited mint keys in hot wallets
- See [security.md](security.md)

---

## Contract upgrade strategy *(PROPOSED)*

Prefer minimal proxies with timelocked upgrades for marketplace; immutable asset logic where possible. Publish upgrade policy.

---

## Auditing

External audit before public mint/market. Retest on material changes. Bug bounty post-launch (Phase 7+).

---

## Disaster recovery

| Scenario | Response sketch |
|---|---|
| Critical contract bug | Pause; communicate; patch via published process |
| Indexer failure | Replay from chain; read-only mode |
| Key compromise | Rotate; freeze; incident plan |
| Chain outage | Degraded ownership/market modes; matches may continue on last-synced ownership with clear user messaging |

---

## Web3 MVP scope

**DECIDED:** Web3 is in the **MVP path** (not a post-launch maybe). See roadmap Phases 1–3.

**MVP chain slice:**

- Embedded wallet create/recover for every account path
- Player asset collection (mint/bind)
- Ownership sync into roster / inventory
- Indexer + admin pause
- Basic marketplace list/buy (MVP or immediate follow-on — roadmap)
- Fee routing
- Gas abstraction for onboarding mints/claims

**Not in Web3 MVP:** Fungible token, DAO, lending, cross-chain bridges (FUTURE / high risk), on-chain live match simulation, minting every match result.

---

## Open questions

- Chain selection (**core** workstream — blockchain expertise required)
- Wallet/AA provider
- Which cosmetics are on-chain vs entitlement
- When starter/tutorial players become fully transferable on-chain
- Royalty policy
