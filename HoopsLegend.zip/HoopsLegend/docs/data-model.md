# Data Model — HoopsLegend (working title)

## Document control

| Field | Value |
|---|---|
| Document ID | CR-DOC-008 |
| Title | Data Model |
| Project | HoopsLegend (working title) |
| Version | 1.1 |
| Status | Design draft |
| Classification | Internal / Confidential |
| Date created | 8 September 2026 |

Status tags: **DECIDED** · **PROPOSED** · **OPEN QUESTION** · **FUTURE** · **REJECTED**

Internal use only. Entity definitions for a blockchain basketball product — not an implementation spec.

Conceptual model only. No schema SQL, no vendor lock-in. Wallet + on-chain asset binding are first-class.

---

## Modeling principles

| Principle | Status |
|---|---|
| Player/asset ownership on-chain is canonical for tradable players | DECIDED |
| Competitive match results authoritative off-chain | DECIDED |
| On-chain ownership mirrored into game projections | DECIDED |
| Soft currency high-frequency ledger off-chain | DECIDED |
| Avoid minting every career tick on-chain | PROPOSED |

---

## On-chain vs off-chain

| Data | Typical location |
|---|---|
| User profile, MMR, chat | Off-chain |
| Attributes, XP, training | Off-chain |
| Match ticks / physics | Off-chain (ephemeral + logs) |
| Career aggregates | Off-chain canonical |
| NFT tokenId ↔ playerId | Both (binding) |
| Marketplace listing settlement | On-chain when asset on-chain |
| Deposit/withdrawal business ledger | Off-chain (+ PSP/chain rails) |

---

## Entity catalog

### User

| | |
|---|---|
| **Purpose** | Human identity in the game |
| **Fields *(PROPOSED)*** | userId, displayName, createdAt, locale, status, fairPlayScore |
| **Relations** | Account, Notification, Club memberships |
| **Lifecycle** | Register → active → suspended/banned → deleted/anonymized |

### Account

| | |
|---|---|
| **Purpose** | Auth credentials and session root |
| **Fields** | accountId, userId, authProviders[], mfaEnabled, lastLogin |
| **Relations** | User, Wallet link |
| **Lifecycle** | Create → link providers → recover → close |

### Wallet

| | |
|---|---|
| **Purpose** | Blockchain address association |
| **Fields** | walletId, userId, address, type (embedded/external), status |
| **Relations** | User, on-chain Asset ownership |
| **Lifecycle** | Create/link → active → rotate/revoke |

### Player

| | |
|---|---|
| **Purpose** | Persistent digital athlete |
| **Fields** | playerId, name, position, rarityTier, ownerUserId/clubId, status, tokenRef? |
| **Relations** | PlayerAttributes, PlayerCareer, Contract, Team roster |
| **Lifecycle** | Generate/mint → develop → trade → retire |

### PlayerCareer

| | |
|---|---|
| **Purpose** | Aggregate history & milestones |
| **Fields** | playerId, games, pts, ast, reb, wins, awards[], clubsHistory[] |
| **Relations** | Player, MatchResult contributions |
| **Lifecycle** | Append-only aggregates; corrections via audited repairs |

### PlayerAttributes

| | |
|---|---|
| **Purpose** | Current ratings |
| **Fields** | physical{}, offense{}, defense{}, mental{}, overall? |
| **Relations** | Player, PlayerTraining |
| **Lifecycle** | Update via training/matches within caps |

### PlayerTraining

| | |
|---|---|
| **Purpose** | Training sessions & spend |
| **Fields** | trainingId, playerId, type, cost, startedAt, completedAt, gains |
| **Relations** | Player, CurrencyBalance movements |
| **Lifecycle** | Queue → complete → apply |

### PlayerAchievement

| | |
|---|---|
| **Purpose** | Badges, awards, attestations |
| **Fields** | achievementId, playerId, code, earnedAt, seasonId, onChainAttestation? |
| **Relations** | Player, Season |
| **Lifecycle** | Earn → display → optional attest |

### Team

| | |
|---|---|
| **Purpose** | Match lineup instance or persistent squad |
| **Fields** | teamId, clubId?, playerIds[], chemistry |
| **Relations** | Club, Match |
| **Lifecycle** | Form → compete → dissolve/update |

### Club

| | |
|---|---|
| **Purpose** | Persistent organization |
| **Fields** | clubId, name, tag, ownerUserId, crest, level, status |
| **Relations** | Members, Teams, Academy?, Inventory |
| **Lifecycle** | Found → operate → transfer ownership → archive |

### Academy

| | |
|---|---|
| **Purpose** | Talent development org |
| **Fields** | academyId, clubId?, reputation, capacity |
| **Relations** | Prospects (Players), Coach |
| **Lifecycle** | Found → train cohorts → graduate |

### Coach

| | |
|---|---|
| **Purpose** | Coaching role / staff entity |
| **Fields** | coachId, userId?, specialties[], clubId |
| **Relations** | Club, Academy, Team |
| **Lifecycle** | Hire → assign → release |

### Scout

| | |
|---|---|
| **Purpose** | Scouting role & reports |
| **Fields** | scoutId, userId, skill, energy |
| **Relations** | Reports → Player prospects |
| **Lifecycle** | Assign → report → cooldown |

### Contract

| | |
|---|---|
| **Purpose** | Terms binding player to club/owner |
| **Fields** | contractId, playerId, clubId, start, end, wageSoft, clauses{} |
| **Relations** | Player, Club, Transfer |
| **Lifecycle** | Sign → active → expire/terminate |

### Transfer

| | |
|---|---|
| **Purpose** | Movement of player rights |
| **Fields** | transferId, playerId, from, to, price, status, marketListingId? |
| **Relations** | Contract, MarketplaceListing, Transaction |
| **Lifecycle** | Propose → accept → settle → complete |

### Match

| | |
|---|---|
| **Purpose** | Scheduled/running game instance |
| **Fields** | matchId, mode, seasonId, serverRegion, status, startedAt |
| **Relations** | Teams, MatchResult |
| **Lifecycle** | Create → live → finished / void |

### MatchResult

| | |
|---|---|
| **Purpose** | Authoritative outcome |
| **Fields** | matchId, scoreHome, scoreAway, playerStats[], validationHash, antiCheatFlags |
| **Relations** | Match, Rewards, Career updates |
| **Lifecycle** | Finalize → reward → archive |

### Tournament

| | |
|---|---|
| **Purpose** | Bracket / event |
| **Fields** | tournamentId, rules, entryFee, prizeSpec, status |
| **Relations** | Matches, Season? |
| **Lifecycle** | Announce → run → complete |

### League

| | |
|---|---|
| **Purpose** | Multi-week club competition |
| **Fields** | leagueId, tier, schedule |
| **Relations** | Clubs, Season |
| **Lifecycle** | Season start → end |

### Season

| | |
|---|---|
| **Purpose** | Time-boxed competitive era |
| **Fields** | seasonId, startsAt, endsAt, rewardTable |
| **Relations** | Rankings, Tournaments |
| **Lifecycle** | Schedule → active → close → archive |

### Ranking

| | |
|---|---|
| **Purpose** | Ladder placement |
| **Fields** | userId/teamId, mmr, rankTier, seasonId |
| **Relations** | Season, User/Team |
| **Lifecycle** | Update per match; soft reset per season |

### Reward

| | |
|---|---|
| **Purpose** | Grant records |
| **Fields** | rewardId, grantee, type, amount/asset, sourceRef, status |
| **Relations** | Match/Tournament/Season, CurrencyBalance/Inventory |
| **Lifecycle** | Pending → granted → clawback(rare, audited) |

### Inventory

| | |
|---|---|
| **Purpose** | Entitlements held by user/club |
| **Fields** | inventoryId, ownerRef, items[] |
| **Relations** | Asset, User/Club |
| **Lifecycle** | Add → equip → remove |

### Asset

| | |
|---|---|
| **Purpose** | Soft entitlement or chain-linked item |
| **Fields** | assetId, type, metadata, tokenRef?, tradable |
| **Relations** | Inventory, MarketplaceListing |
| **Lifecycle** | Create → own → trade → burn/retire |

### MarketplaceListing

| | |
|---|---|
| **Purpose** | Sell offer |
| **Fields** | listingId, assetId, seller, price, currency, status, txRefs |
| **Relations** | Asset, Transaction |
| **Lifecycle** | List → sold/canceled/expired |

### Transaction

| | |
|---|---|
| **Purpose** | Generic economic event |
| **Fields** | txId, type, parties, amounts, status, createdAt |
| **Relations** | Deposit, Withdrawal, Marketplace |
| **Lifecycle** | Create → post → settle/fail |

### Deposit

| | |
|---|---|
| **Purpose** | Funds in |
| **Fields** | depositId, userId, rail, amount, pspRef, status |
| **Relations** | CurrencyBalance, Transaction |
| **Lifecycle** | Initiate → confirm → credit |

### Withdrawal

| | |
|---|---|
| **Purpose** | Funds out |
| **Fields** | withdrawalId, userId, amount, rail, kycState, status |
| **Relations** | CurrencyBalance, Transaction |
| **Lifecycle** | Request → review → payout/reject |

### CurrencyBalance

| | |
|---|---|
| **Purpose** | Soft/premium/cash-ledger balances |
| **Fields** | ownerRef, currencyCode, available, held |
| **Relations** | Ledger entries via Transaction |
| **Lifecycle** | Credit/debit with double-entry style (**PROPOSED**) |

### Notification

| | |
|---|---|
| **Purpose** | User messaging |
| **Fields** | notificationId, userId, type, payload, readAt |
| **Lifecycle** | Create → read → expire |

### AuditLog

| | |
|---|---|
| **Purpose** | Security & support trail |
| **Fields** | auditId, actor, action, target, at, meta |
| **Lifecycle** | Append-only |

---

## Relationship diagram *(simplified)*

```mermaid
erDiagram
  USER ||--o{ ACCOUNT : has
  USER ||--o| WALLET : links
  USER ||--o{ PLAYER : owns
  CLUB ||--o{ PLAYER : rosters
  CLUB ||--o| ACADEMY : may_have
  PLAYER ||--|| PLAYER_ATTRIBUTES : has
  PLAYER ||--|| PLAYER_CAREER : has
  PLAYER ||--o{ CONTRACT : under
  CONTRACT ||--o{ TRANSFER : leads_to
  MATCH ||--|| MATCH_RESULT : produces
  MATCH }o--o{ PLAYER : features
  SEASON ||--o{ RANKING : tracks
  ASSET ||--o{ MARKETPLACE_LISTING : listed_as
  USER ||--o{ CURRENCY_BALANCE : holds
  USER ||--o{ DEPOSIT : makes
  USER ||--o{ WITHDRAWAL : requests
```

---

## Lifecycle notes

- **MatchResult** drives Career, Ranking, Reward—never trust raw client totals.
- **Asset.tokenRef** present only when bridged/minted.
- **Held** balances used for escrow (listings, withdrawals).

---

## Open questions

- Hard delete vs soft delete / GDPR erasure strategy
- Whether Team is persistent squad vs ephemeral match lineup only
- Career correction policy after dispute
- Schema migration approach
