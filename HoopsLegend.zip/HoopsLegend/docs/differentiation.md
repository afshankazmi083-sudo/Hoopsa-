# Differentiation — HoopsLegend (working title)

## Document control

| Field | Value |
|---|---|
| Document ID | CR-DOC-003 |
| Title | Differentiation |
| Project | HoopsLegend (working title) |
| Version | 1.1 |
| Status | Design draft |
| Classification | Internal / Confidential |
| Date created | 8 September 2026 |

Status tags: **DECIDED** · **PROPOSED** · **OPEN QUESTION** · **FUTURE** · **REJECTED**

Internal use only. Competitive notes for the team — not marketing copy for public release.

This note answers: why this **blockchain basketball** game instead of sims, fantasy, or thin NFT sports?

We are not citing market numbers we have not verified. Anything that needs outside research is marked **Needs verification**.

---

## Category analysis

### NBA-style / console basketball games

| Strengths *(observation)* | Gaps vs HoopsLegend *(hypothesis)* |
|---|---|
| High production gameplay, licensed presentation | Limited user ownership of player economies; careers tied to publisher account silos |
| Broad audience | Rare academy/scouting-as-economy loops |

### Mobile basketball games

| Strengths | Gaps |
|---|---|
| Accessibility, short sessions | Often shallow progression; heavy monetization pressure *(title-dependent; Needs verification)* |

### Fantasy sports

| Strengths | Gaps |
|---|---|
| Real-world tie-in, seasonal engagement | Little skill-based basketball control; digital “players” are mirrors of external athletes |

### NFT sports games

| Strengths | Gaps |
|---|---|
| Clear ownership narrative | Gameplay often secondary; retention tied to speculation *(Needs verification per title)* |

### Web3 basketball games

| Strengths | Gaps |
|---|---|
| Experimentation with on-chain assets | Wallet friction; unclear fair-play; chain actions for non-valuable events |

### Sports management games

| Strengths | Gaps |
|---|---|
| Deep roster/tactics systems | Weaker visceral play; limited portable ownership |

### Play-to-earn games

| Strengths | Gaps |
|---|---|
| Strong early incentive loops | Unsustainable emissions; bot farming; P2W stigma — **REJECTED as primary model** |

---

## Comparison matrix *(conceptual)*

Ratings are **relative design intent**, not measured market scores.

Legend: ● Strong · ◐ Partial · ○ Weak / Rare · — N/A or atypical

| Dimension | NBA-style | Mobile BB | Fantasy | NFT sports | Mgmt games | P2E | **HoopsLegend (PROPOSED)** |
|---|---|---|---|---|---|---|---|
| Gameplay (skill basketball) | ● | ◐ | ○ | ◐ | ○ | ◐ | ● |
| Player ownership | ○ | ○ | ○ | ● | ○ | ● | ● |
| Player progression | ● | ◐ | ○ | ◐ | ● | ◐ | ● |
| Career history as product | ◐ | ○ | ◐ | ○ | ◐ | ○ | ● |
| Scouting | ○ | ○ | ◐ | ○ | ● | ○ | ● |
| Clubs | ◐ | ◐ | ○ | ◐ | ● | ◐ | ● |
| Academies | ○ | ○ | ○ | ○ | ◐ | ○ | ● |
| Transfers | ○ | ○ | ○ | ● | ● | ● | ● |
| Competition depth | ● | ◐ | ● | ◐ | ● | ◐ | ● |
| Marketplace | ○ | ◐ | ○ | ● | ○ | ● | ● |
| Blockchain | ○ | ○ | ○ | ● | ○ | ● | ● Core |
| Real-world integration | ● Licensed | ◐ | ● | ◐ | ○ | ○ | FUTURE optional |
| Multi-role users | ◐ | ○ | ○ | ◐ | ● | ◐ | ● |
| Economic participation | ○ | ◐ | ◐ | ● | ○ | ● | ● Fair, non-P2W |

---

## Proposed differentiators

### 1. Persistent player careers

| Aspect | Detail |
|---|---|
| **What** | Players accumulate verifiable performance history and milestones |
| **Why it matters** | Turns matches into lasting narrative and economic signal |
| **User benefit** | Attachment, prestige, informed trading |
| **Why it helps vs others** | Harder for collectible-only titles to copy without real play |
| **Technical** | Career ledger off-chain + selective on-chain proofs/achievements |
| **Economic** | Value tied to performance, not only rarity |
| **Risks** | History rewriting attacks; privacy; storage growth |

### 2. Talent discovery (scouting)

| Aspect | Detail |
|---|---|
| **What** | Users find and evaluate prospects with incomplete information |
| **Why** | Creates skillful meta beyond button skill |
| **User benefit** | Agency for non-aim gods; long arcs |
| **Why it helps vs others** | Distinct from pure ranked shooters and pure fantasy |
| **Technical** | Hidden stats, reveal rules, anti-bot evaluation |
| **Economic** | Information markets; must avoid pay-to-omniscience |
| **Risks** | Bots, RMT of intel, frustration if too random |

### 3. Club ecosystem

| Aspect | Detail |
|---|---|
| **What** | User-run organizations with roster, brand, competition |
| **Why** | Social retention and identity |
| **User benefit** | Belonging, leadership roles |
| **Why it helps vs others** | Sticky vs solo-only games |
| **Technical** | Permissions, club inventory, season enrollment |
| **Economic** | Club sinks (facilities, fees); shared rewards rules |
| **Risks** | Toxicity, inactive owners, governance disputes |

### 4. Academy system

| Aspect | Detail |
|---|---|
| **What** | Develop talent before/alongside senior competition |
| **Why** | Deepens progression fantasy of basketball orgs |
| **User benefit** | Long-term projects; teaching/meta skill |
| **Why it helps vs others** | Rare in action-sports hybrids |
| **Technical** | Parallel progression sims; graduation pipelines |
| **Economic** | Training sinks; graduate transfer value |
| **Risks** | Complexity; dead content if population low |

### 5. Transfer economy

| Aspect | Detail |
|---|---|
| **What** | Players move based on contracts, performance, and market |
| **Why** | Living economy instead of dead inventory |
| **User benefit** | Strategic roster craft; exit liquidity for owned assets |
| **Why it helps vs others** | Bridges gameplay and ownership better than mint drops |
| **Technical** | Off-chain match + on-chain settlement options |
| **Economic** | Fees, price discovery, anti-wash-trading |
| **Risks** | Inflation of supply; collusion; regulatory classification |

### 6. Multiple roles

| Aspect | Detail |
|---|---|
| **What** | Player, coach, scout, club/academy owner, collector, fan |
| **Why** | Broader audience; different session lengths |
| **User benefit** | Play your way |
| **Why it helps vs others** | Ecosystem density |
| **Technical** | Role permissions and UX modes |
| **Economic** | Multiple spend/earn profiles |
| **Risks** | Diluted MVP; feature sprawl |

### 7. Real-world connection *(FUTURE)*

| Aspect | Detail |
|---|---|
| **What** | Optional links from physical play/events to digital progress |
| **Why** | Authentic basketball culture bridge |
| **User benefit** | Training motivation; local community |
| **Why it helps vs others** | Differentiation vs pure digital or pure fantasy |
| **Technical** | Verification, fraud, device/sensor trust |
| **Economic** | Partnerships; must not sell fake “earn salary” promises |
| **Risks** | Cheating sensors; liability; scope |

### 8. Blockchain as the ownership layer (core)

| Aspect | Detail |
|---|---|
| **What** | Players and selected assets owned on-chain; marketplace settlement on-chain; live matches off-chain |
| **Why** | Product category is blockchain basketball — ownership is not a side quest |
| **User benefit** | Portable assets + usable wallet UX (embedded + gas abstraction) |
| **Why it helps vs others** | Beats “NFT shelf with minigame” and “sports game maybe crypto later” |
| **Technical** | Indexers, embedded wallets, AA; chain selection is a core workstream |
| **Economic** | Marketplace fees; no mandatory fungible token for MVP |
| **Risks** | Key loss; bad UX if gas abstraction fails; chain regret |

---

## Positioning (PROPOSED)

HoopsLegend is **blockchain basketball**: own players on-chain, compete for career value, build orgs, trade with provenance — not a speculation booth, and not a traditional sports title with optional crypto.

---

## Rejected positioning

| Position | Status |
|---|---|
| “NFT basketball marketplace with minigames” | REJECTED |
| “Guaranteed passive income basketball” | REJECTED |
| “On-chain physics basketball” | REJECTED |
| “Traditional basketball game; crypto optional later” | REJECTED |

---

## Open questions

- Priority order of differentiators for marketing (on-chain ownership vs careers vs clubs)
- Whether real-world integration is pursued within first two major expansions
- Competitor shortlist for ongoing tracking *(Requires research)*
