# Technical Architecture — HoopsLegend (working title)

## Document control

| Field | Value |
|---|---|
| Document ID | CR-DOC-007 |
| Title | Technical Architecture |
| Project | HoopsLegend (working title) |
| Version | 1.1 |
| Status | Design draft |
| Classification | Internal / Confidential |
| Date created | 8 September 2026 |

Status tags: **DECIDED** · **PROPOSED** · **OPEN QUESTION** · **FUTURE** · **REJECTED**

Internal use only. Architecture for a **blockchain basketball** product. Engine and cloud vendors are not decided; **chain selection is a core workstream**.

---

## Architecture goals

| Goal | Status |
|---|---|
| Blockchain ownership services from early phases | DECIDED |
| Server owns competitive match outcomes | DECIDED |
| Game, economy, and Web3 evolve together (not “chain later”) | DECIDED |
| Matchmaking can scale on its own | PROPOSED |
| Security and observability from day one (incl. wallets/contracts) | DECIDED |
| No vendor lock without a real evaluation | DECIDED |

---

## High-level architecture

```mermaid
flowchart TB
  Client[Game Client + UI]
  GW[API Gateway]
  Auth[Auth Service]
  GameSvc[Game / Match Services]
  MM[Matchmaking]
  Econ[Economy Service]
  Inv[Inventory / Players]
  Social[Clubs / Social]
  Pay[Payments]
  Chain[Blockchain Service]
  Idx[Indexer]
  DB[(Primary Datastores)]
  Cache[(Cache / PubSub)]
  ChainNet[Blockchain Network]

  Client --> GW
  GW --> Auth
  GW --> GameSvc
  GW --> Econ
  GW --> Inv
  GW --> Social
  GW --> Pay
  Client -->|Realtime| GameSvc
  GameSvc --> MM
  GameSvc --> DB
  GameSvc --> Cache
  Econ --> DB
  Inv --> DB
  Pay --> Econ
  Chain --> ChainNet
  Idx --> ChainNet
  Idx --> Inv
  Chain --> Econ
```

---

## Client

| Concern | Notes |
|---|---|
| Game client | Renders court, inputs, prediction/reconciliation |
| UI shell | Account, inventory, shop, club, marketplace |
| Account | Email/social/guest→upgrade paths (**PROPOSED**) |
| Inventory | Players, cosmetics, currencies |
| Marketplace | Listings UX; waits on chain confirmations when needed |

---

## Game engine *(OPEN QUESTION)*

**Do not lock engine yet.** Selection criteria:

| Criterion | Why |
|---|---|
| Networking / dedicated server support | Competitive integrity |
| Physics adequacy | Basketball feel |
| Tooling & hiring pool | Delivery speed |
| Platform targets | PC/mobile/console roadmap |
| Licensing cost | Business |
| Web/performance options | If companion or light clients |

Candidates may include Unity, Unreal, Godot, or custom—**Requires evaluation**.

---

## Game server

**DECIDED:** Server-authoritative simulation for ranked/competitive modes.

| Responsibility | Notes |
|---|---|
| Simulate match | Authoritative ball/player state |
| Validate inputs | Reject impossible actions |
| Persist results | Signed/result tickets to backend |
| Anti-cheat hooks | Timings, stats anomalies |

Client-side prediction allowed for feel; server wins conflicts.

---

## Backend services *(PROPOSED list)*

| Service | Responsibility |
|---|---|
| Authentication | Identity, sessions, MFA |
| Users | Profiles, preferences |
| Players | Attributes, progression |
| Clubs | Orgs, roles |
| Academies | Development pipelines (later) |
| Matches | History, validation |
| Matchmaking | Queues, parties, skill |
| Rankings | MMR, seasons |
| Tournaments | Brackets |
| Economy | Balances, sinks/sources |
| Inventory | Entitlements |
| Marketplace | Listings orchestration |
| Wallet / Web3 | Address link, tx intents |
| Notifications | Push/email/in-app |
| Analytics | Events, funnels |
| Admin | Support, bans, economy knobs |

Service boundaries may start modular monolith then split—**PROPOSED** evolutionary approach.

---

## Database

| Need | Approach *(PROPOSED)* |
|---|---|
| Relational | Users, economy ledgers, clubs, matches |
| Document | Flexible metadata, configs |
| Cache | Sessions, matchmaking, hot profiles |
| Time-series / events | Analytics (optional store) |
| Search | Player/club discovery later |

**OPEN QUESTION:** Exact vendors (Postgres, Redis, etc.—likely, but not finalized as DECIDED).

---

## API

| Style | Use |
|---|---|
| REST or GraphQL | CRUD, inventory, shop |
| WebSocket / dedicated UDP/TCP | Gameplay netcode |
| Webhooks | Payments, chain indexer |

Version APIs; idempotency keys for payments and marketplace.

---

## Real-time networking

- Tick rate tuned for basketball (**OPEN QUESTION** exact Hz)
- Interest management for 3v3 modest scale
- Region-local game servers
- Latency-based matchmaking constraints

---

## Matchmaking

Skill + latency + party size + fair roles. Avoid pay-based lobby advantages. Smurf detection hooks.

---

## AI

Server-side bots for practice and disconnect fill; difficulty presets; never privileged vs anti-cheat rules asymmetrically in ranked without disclosure.

---

## Blockchain service

Creates tx intents, submits sponsored txs, monitors status, exposes ownership to inventory via indexer projections. See the Web3 doc.

---

## Indexer

Ingests chain events → normalized DB. Handles reorgs; exposes internal APIs; alerts on lag.

---

## Payments

PSP integration; webhook verification; ledger entries; chargeback workflow. Crypto payments optional and separate risk track.

---

## Admin system

Support tools: grant/revoke, ban, replay match, freeze withdrawals, pause marketplace, adjust feature flags. Full audit log.

---

## Analytics

Event taxonomy: funnel, match quality, economy, retention. Privacy-compliant.

---

## Logging & monitoring

Structured logs, metrics, traces. SLOs for API latency, match server health, indexer lag, payment success.

---

## Deployment & CI/CD *(PROPOSED)*

- Containerized services
- Environments: dev / staging / prod
- Automated tests + migration checks
- Separate promote path for contracts vs app

---

## Cloud

**OPEN QUESTION:** Provider not locked. Criteria: global regions near players, managed DB/KMS, cost, compliance certifications.

---

## Scalability

| Tier | Strategy |
|---|---|
| Match servers | Horizontal by region/shard |
| Matchmaking | Partitioned queues |
| Datastores | Read replicas, caching |
| Marketplace | Rate limits; async settlement |

---

## Availability & performance *(PROPOSED targets — not contractual)*

| Area | Early target |
|---|---|
| API availability | Aim high-nines progressively |
| Match join time | Short queue in populated regions |
| Tick hitches | Minimize; measure FPS/sim |

Exact SLOs set during Phase 2.

---

## Disaster recovery

Backups, RPO/RTO objectives (**OPEN QUESTION** numbers), region failover plan, marketplace pause runbook, match result repair tools.

---

## Technical risks

| Risk | Mitigation sketch |
|---|---|
| Engine mis-choice | Spike prototypes early (Phase 1) |
| Cheat clients | Authority + detection |
| Economy exploits | Ledgers, caps, audits |
| Chain congestion | Gas abstraction; queue UX |
| Scope creep | MVP boundary in roadmap |

---

## Open questions

- Game engine
- Cloud provider
- Monolith vs microservices timing
- Netcode transport details
- Mobile architecture share with PC
